G00359656 Data Structures and Algorithms Project 
- Description
	- Read a .txt file and output a wordcloud containing the most frequent words in the file
- Features include:
	- Parsing a .txt file
	- Creating a wordcloud image
	- Allows user to name the png file created
	- Allows user to choose amount of words to be displayed in their wordcloud